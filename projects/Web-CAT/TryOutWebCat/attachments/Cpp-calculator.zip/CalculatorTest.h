#ifndef CALCULATORTEST_
#define CALCULATORTEST_

#include <cxxtest/TestSuite.h>
#include "Calculator.h"

//-------------------------------------------------------------------------
/**
 *  Test class for Calculator.
 *
 *  @author  Stephen Edwards
 *  @version 2006.06.14
 */
class CalculatorTest :
    public CxxTest::TestSuite
{
public:
    // ----------------------------------------------------------
    /**
     * Check that a new calculator starts off with a zero value.
     */
    void testInitial()
    {
        Calculator calc;
        TS_ASSERT_EQUALS( calc.getValue(), 0 );
    }

    // ----------------------------------------------------------
    /**
     * Check setValue/getValue.
     */
    void testSetValue()
    {
        Calculator calc;
        calc.setValue( 37 );
        TS_ASSERT_EQUALS( calc.getValue(), 37 );
        calc.setValue( -42 );
        TS_ASSERT_EQUALS( calc.getValue(), -42 );
    }

    // ----------------------------------------------------------
    /**
     * Check that clear returns the accumulator to zero.
     */
    void testClear()
    {
        Calculator calc;
        calc.setValue( 49 );
        calc.clear();
        TS_ASSERT_EQUALS( calc.getValue(), 0 );
    }

    // ----------------------------------------------------------
    /**
     * Check that add works on zero and non-zero accumulators.
     */
    void testAdd()
    {
        Calculator calc;
        // Add your own test actions here
    }

    // ----------------------------------------------------------
    /**
     * Check that subtract works on zero and non-zero accumulators.
     */
    void testSubtract()
    {
        Calculator calc;
        // Add your own test actions here
    }

    // ----------------------------------------------------------
    /**
     * Check that multiplyBy works on non-zero accumulators.
     */
    void testMultiplyBy()
    {
        Calculator calc;
        // Add your own test actions here
    }

    // ----------------------------------------------------------
    /**
     * Check that divideBy works on non-zero accumulators.
     */
    void testDivideBy()
    {
        Calculator calc;
        // Add your own test actions here
    }
};

#endif /*CALCULATORTEST_*/
