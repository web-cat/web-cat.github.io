import junit.framework.*;

//-------------------------------------------------------------------------
/**
 *  Test class for Calculator.
 *
 *  @author  Stephen Edwards
 *  @version 2006.06.14
 */
public class CalculatorTest
    extends TestCase
{
    //~ Setup .................................................................

    // ----------------------------------------------------------
    /**
     * Creates a new Calculator object with zero in the accumulator.
     */
    public void setUp()
    {
        calc = new Calculator();
    }


    //~ Public Methods ........................................................

    // ----------------------------------------------------------
    /**
     * Check that a new calculator starts off with a zero value.
     */
    public void testInitial()
    {
        assertEquals( calc.getValue(), 0 );
    }

    // ----------------------------------------------------------
    /**
     * Check setValue/getValue.
     */
    public void testSetValue()
    {
        calc.setValue( 37 );
        assertEquals( calc.getValue(), 37 );
        calc.setValue( -42 );
        assertEquals( calc.getValue(), -42 );
    }

    // ----------------------------------------------------------
    /**
     * Check that clear returns the accumulator to zero.
     */
    public void testClear()
    {
        calc.setValue( 49 );
        calc.clear();
        assertEquals( calc.getValue(), 0 );
    }

    // ----------------------------------------------------------
    /**
     * Check that add works on zero and non-zero accumulators.
     */
    public void testAdd()
    {
        // Add your own test actions here
    }

    // ----------------------------------------------------------
    /**
     * Check that subtract works on zero and non-zero accumulators.
     */
    public void testSubtract()
    {
        // Add your own test actions here
    }

    // ----------------------------------------------------------
    /**
     * Check that multiplyBy works on non-zero accumulators.
     */
    public void testMultiplyBy()
    {
        // Add your own test actions here
    }

    // ----------------------------------------------------------
    /**
     * Check that divideBy works on non-zero accumulators.
     */
    public void testDivideBy()
    {
        // Add your own test actions here
    }


    //~ Instance/static variables .............................................

    private Calculator calc;
}
