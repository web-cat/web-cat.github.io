#include "Calculator.h"

// -------------------------------------------------------------------------
Calculator::Calculator()
{
    value = 0;
}


// -------------------------------------------------------------------------
Calculator::~Calculator()
{
}


// -------------------------------------------------------------------------
int Calculator::getValue() const
{
    return value;
}


// -------------------------------------------------------------------------
void Calculator::setValue( int val )
{
    value = val;
}


// -------------------------------------------------------------------------
void Calculator::clear()
{
    setValue( 0 );
}


// -------------------------------------------------------------------------
void Calculator::add( int val )
{
    setValue( getValue() + val );
}


// -------------------------------------------------------------------------
void Calculator::subtract( int val )
{
    setValue( getValue() - val );
}


// -------------------------------------------------------------------------
void Calculator::multiplyBy( int val )
{
    setValue( getValue() * val );
}


// -------------------------------------------------------------------------
void Calculator::divideBy( int val )
{
    setValue( getValue() / val );
}
