#ifndef CALCULATORTEST_
#define CALCULATORTEST_

#include <cxxtest/TestSuite.h>
#include "Calculator.h"

//-------------------------------------------------------------------------
/**
 *  Test class for Calculator.
 *
 *  @author  Stephen Edwards
 *  @version 2006.06.14
 */
class CalculatorTest :
    public CxxTest::TestSuite
{
public:
    // ----------------------------------------------------------
    /**
     * Check that a new calculator starts off with a zero value.
     */
    void testInitial()
    {
        Calculator calc;
        TS_ASSERT_EQUALS( calc.getValue(), 0 );
    }

    // ----------------------------------------------------------
    /**
     * Check setValue/getValue.
     */
    void testSetValue()
    {
        Calculator calc;
        // Add your own test actions here
    }
};

#endif /*CALCULATORTEST_*/
